<?php

return [
    'paths' => [
        'migrations' => '%%PHINX_CONFIG_DIR%%/php/migrations',
        'seeds' => '%%PHINX_CONFIG_DIR%%/php/seeds'
    ],
    'environments' => [
        'default_migration_table' => 'migrations',
        'default_environment' => 'production',
        'production' => [
            'adapter' => 'mysql',
            'host' => 'clean-php-mysql',
            'name' => getenv('MYSQL_NAME'),
            'user' => getenv('MYSQL_USER'),
            'pass' => getenv('MYSQL_PASSWORD'),
            'port' => 3306,
            'charset' => 'utf8',
        ]
    ],
    'version_order' => 'creation'
];
