<?php

declare(strict_types=1);

namespace app;

use PDO;
use PDOException;

class Database
{
    private static PDO|null $pdo = null;

    public static function getConnection(): PDO
    {
        if (self::$pdo === null) {
            $config = Config::getInstance()->get('db');
            try {
                self::$pdo = new PDO(
                    $config['dsn'],
                    $config['username'],
                    $config['password']
                );
            } catch (PDOException $e) {
                die('Ошибка подключения: ' . $e->getMessage());
            }
        }
        return self::$pdo;
    }
}