<?php

declare(strict_types=1);

namespace app\Repository;

use app\Database;
use app\DTO\LoadDTO;
use PDO;
use app\Factory\LoadFactory;

class LoadRepository
{
    private PDO $pdo;
    private LoadFactory $factory;

    public function __construct()
    {
        $this->pdo = Database::getConnection();
        $this->factory = new LoadFactory();
    }

    public function save(LoadDTO $load): void
    {
    }

    public function update(int $id, LoadDTO $load): void
    {
    }

    public function delete(int $id): void
    {
    }

    public function findAll(): array
    {
    }

    public function findAllWithCategories(): array
    {
        $query = 'SELECT * FROM loads';
        $stmt = $this->pdo->prepare($query);
        $stmt->execute();

        $loads = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $loads[] = $this->factory->createLoadFromDatabaseRow($row);
        }

        return $loads;
    }
}