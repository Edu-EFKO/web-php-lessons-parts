<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

const PROJECT_ROOT = __DIR__ . '/../';

require_once PROJECT_ROOT . 'vendor/autoload.php';

// TODO добавить получение всех грузов из базы данных

include 'header.php';
?>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="card-title">Все грузы</h5>
        <a href="add_load.php" class="btn btn-primary">Добавить новый груз</a>
    </div>

    <?php if (empty($loads) === true): ?>
        <p>На данный момент нет грузов.</p>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Наименование</th>
                    <th>Тоннаж (т.)</th>
                    <th>Дальность (км)</th>
                    <th>Ставка (руб/км)</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loads as $load): ?>
                    <tr>
                        <td><?= $load['id'] ?></td>
                        <td><?= $load['name'] ?></td>
                        <td><?= $load['tonnage'] ?></td>
                        <td><?= $load['distance'] ?></td>
                        <td><?= $load['rate'] ?></td>
                        <td><?= $load['is_delivered'] ? 'Доставлен' : 'Не доставлен' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>