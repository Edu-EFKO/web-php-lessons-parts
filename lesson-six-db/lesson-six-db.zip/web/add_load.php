<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

const PROJECT_ROOT = __DIR__ . '/../';

require_once PROJECT_ROOT . 'vendor/autoload.php';

// TODO добавить сохранение нового груза в базу данных

include 'header.php';
?>

<div class="container mt-5">
    <h2 class="mb-4">Добавление нового груза</h2>
    <form action="add_load.php" method="post">
        <div class="mb-3">
            <label for="name" class="form-label">Наименование:</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="tonnage" class="form-label">Тоннаж (т):</label>
            <input type="number" name="tonnage" id="tonnage" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="distance" class="form-label">Дальность (км):</label>
            <input type="number" name="distance" id="distance" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="rate" class="form-label">Ставка (руб/км):</label>
            <input type="number" name="rate" id="rate" class="form-control" required>
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_delivered" id="is_delivered" class="form-check-input">
            <label for="is_delivered" class="form-check-label">Статус доставки (Доставлен)</label>
        </div>
        <button type="submit" class="btn btn-primary">Добавить груз</button>
    </form>
</div>

<?php include 'footer.php'; ?>