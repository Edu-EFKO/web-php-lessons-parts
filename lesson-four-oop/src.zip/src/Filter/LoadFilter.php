<?php

declare(strict_types=1);

include_once PROJECT_ROOT . 'src/Model/AbstractLoad.php';
include_once PROJECT_ROOT . 'src/Filter/FilterInterface.php';

class LoadFilter implements FilterInterface
{
    private string|null $category;
    private int $minCost;
    private bool|null $status;

    public function __construct(array $queryParams)
    {
        $this->category = htmlspecialchars($queryParams['category'] ?? '');
        $this->minCost = (int)($queryParams['min_cost'] ?? 0);
        $this->status = isset($queryParams['status']) && $queryParams['status'] !== '' ? (bool)$queryParams['status'] : null;
    }

    public function apply(array $loads): array
    {
        return array_filter($loads, function (AbstractLoad $load): bool {
            $cost = $load->calculateCost();
            $isInCategory = empty($this->category) || $load->getCategory() === $this->category;
            $isInCostRange = $cost >= $this->minCost;
            $hasStatus = $this->status === null || $load->isDelivered() === $this->status;

            return $isInCategory && $isInCostRange && $hasStatus;
        });
    }
}