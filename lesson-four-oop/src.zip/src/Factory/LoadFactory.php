<?php

declare(strict_types=1);

include_once PROJECT_ROOT . 'src/Model/FoodLoad.php';
include_once PROJECT_ROOT . 'src/Model/ChemicalLoad.php';
include_once PROJECT_ROOT . 'src/Model/EquipmentLoad.php';

class LoadFactory
{
    private array $loadTypes = [
        FoodLoad::class,
        ChemicalLoad::class,
        EquipmentLoad::class,
    ];

    public function createLoads(int $numberOfLoads): array
    {
        $loads = [];

        for ($i = 1; $i <= $numberOfLoads; $i++) {
            $loadClass = $this->loadTypes[array_rand($this->loadTypes)];
            $loads[] = new $loadClass(
                name: "Груз $i",
                tonnage: random_int(5, 100),
                distance: random_int(50, 1000),
                rate: random_int(3, 20),
                isDelivered: (bool)random_int(0, 1)
            );
        }

        return $loads;
    }
}